describe("Test Suite", () => {
    it("Visiting page", () => {
        cy.visit("https://example.com"); //navigate
        cy.reload(); //reload the page
})
it("finding elements and interacting with elements",() => {
    cy.get('selector') //selectors
cy.contains("text") //text
cy.find('selector') //child elements)
cy.click('element') // clicking elements
cy.type('type the text') //typing text
cy.clear('clear the text') //clearing text
cy.check('check the checkbox') //checking checkboxes
cy.uncheck('uncheck the checkbox') //unchecking checkboxes
cy.select('select option dropdown') //selecting options from dropdowns
})
it('assertions', () => {
    cy.should('be.visible') //asserting visibility
    cy.should('have.text','text') //asserting text
    cy.should('contains','partial text') //asserting partial text
    cy.should('have.text','value') //asserting value
    cy.should('have.attr','attributename','expectedvalue') //asserting attributes
})
it('waiting and timing', () => {
    cy.wait(1000) //waiting for 1 second
    cy.get(ROOT_SELECTOR,{timeout: 10000}) //increase wait time for an element
})
it('handling alerts and popups', () => {
    cy.on('window:alert', (text) => {
        expect(text).to.equal('Expected alert text') //asserting alert text
    })
})
it('working with forms', () => {
    cy.get('form').submit() //submitting a form
    cy.get('selector').select('option') //selecting an option in a form in dropdown
    cy.get('input').check() //checking a checkbox in a form
    cy.get('input').uncheck() //unchecking a checkbox in a form
})
it('file uploads', () => {
    cy.get('input[type="file"]').attachFile('path/to/file') //uploading a file
})
it('screenshot and video recording', () => {
    cy.screenshot() //taking a screenshot
    cy.screenshot('screenshot-name') //name a screenshot
})
it('custom commands', () => {
    cy.get('#user').type('username')
    cy.get('#password').type('password')
    cy.get('#login').click()
})
it('alias and fixtures', () => {
    cy.get('#user').as('username') //aliasing an element
    cy.get('@username').type('username') //using the aliased element
    cy.fixture('data.json').then((data) => {
        cy.get('#input').type(data.input) //using fixture data
    })
    it('API testing', () => {
        cy.request('GET', '/api/data').then((response) => {
            expect(response.status).to.eq(200) //asserting API response status
            expect(response.body).to.have.property('key') //asserting API response body
        })
    })
    cy.intercept('GET', '/api/data').as('getData') //intercepting API calls
})
})                                                                                                                                                     