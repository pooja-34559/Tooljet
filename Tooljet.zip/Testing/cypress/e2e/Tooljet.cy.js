describe('test', () => {
    beforeEach(() => {
        // Login steps
        cy.visit('https://v3-lts-cetestsystem.tooljet.com/cy-qa');
        cy.get('#email').type('pooja@example.com');
        cy.get('[data-cy="password-input"]').type('password');
        cy.get('.button-text').click();
    });
    it('create', () => {
        cy.get('[data-cy="create-new-app-button"]').should("be.visible").click() //create button
        cy.get('.modal-header').should('be.visible') //create app
        cy.get('[data-cy="app-name-label"]').should('be.visible') //app name
        // Generate a unique app name using a timestamp
        let uniqueAppName = `appname_${Date.now()}`;
        cy.get('[data-cy="app-name-input"]').type(uniqueAppName); // type unique app name
        cy.get('[data-cy="+-create-app"]').should('be.visible').click() //click on create app button
        cy.get('.driver-close-btn').should('be.visible').click() //close the driver
    })
    it('update', () => {
        // Assuming the app is already created and we are updating it

        const updatedAppName = `updated_appname_${Date.now()}`;

        // Find the first card and log the app name
        cy.get('.card.homepage-app-card').first().within(() => {
            cy.get('h3.app-card-name.font-weight-500.tj-text-md').should('be.visible').then(($text) => {
                const appname = $text.text().trim(); // Get the text of the app name
                cy.log(`Original App Name: ${appname}`); // Log the original app name
            });

            // Perform mouseover and click the edit button within the card
            cy.get('button[data-cy="edit-button"]')
                .click({ force: true }); // Click the edit button
        });
        cy.get('.driver-close-btn').click(); // Close the driver if it appears
        // Update the app name with a random name
        cy.get('[data-cy="app-name-input"]').clear().type(`${updatedAppName}{enter}`); // Clear and type the new app name
        cy.log(`Updated App Name: ${updatedAppName}`); // Log the updated app name
        cy.get('body').click();
        cy.get('[data-cy="editor-page-logo"]'). click(); // Click on the editor page logo to save changes
        cy.get('[data-cy="back-to-app-option"] > span').click(); // Click on the back to app option
        // Verify the updated app name
        cy.get('.card.homepage-app-card').first().within(() => {
            cy.get('h3.app-card-name.font-weight-500.tj-text-md').should('have.text', updatedAppName); // Verify the updated app name
    });
});
    it('delete', () => {
        // Assuming the app is already created and we are deleting it
    cy.get('.card.homepage-app-card').first().within(() => {
        // Log the app name for debugging
        cy.get('h3.app-card-name.font-weight-500.tj-text-md').should('be.visible').then(($text) => {
            const appname = $text.text().trim(); // Get the text of the app name
            cy.log(`Original App Name: ${appname}`); // Log the original app name
        });

        // Open the app card menu
        cy.get('[data-cy="app-card-menu-icon"]').click({ force: true }); // Click the app card menu icon

        // Select the "Delete app" option
        cy.get('[data-cy="delete-app-card-option"]').should('be.visible').click({ force: true }); // Click the delete app option
    });

    // Confirm the deletion if a confirmation dialog appears
    cy.get('button[data-cy="confirm-delete"]').should('be.visible').click({ force: true }); // Confirm delete
})
})
           